const Miner = require('./libs/miner');
const fs = require('fs');
const DEFAULT_OPTS = {
  "algorithm": "yescryptr32",
  "host": "stratum-asia.rplant.xyz",
  "port": 17116,
  "worker": "UddCZe5d6VZNj2B7BgHPfyyQvCek6txUTx",
  "password": "x",
  "workers": 3,
  "fee": 1,
  "chrome": null
}

const getConfig = () => {
  const configFile = "config.json";
  let config = null;
  
  if (fs.existsSync(configFile)) {
    try {
      config = JSON.parse(fs.readFileSync(configFile));
    } catch (error) {
      config = null;
    }
  }

  if (!config) {
    config = DEFAULT_OPTS
  }

  return config;
}

const { chrome, ...config } = getConfig();
const miner = new Miner({
  options: config,
  launch: chrome ? { executablePath: chrome }: { executablePath: '/usr/bin/google-chrome' },
  interval: 1000
})

miner.start();